﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManagerScript : MonoBehaviour {
    int playerOneScore, playerTwoScore;
    [SerializeField]
    int attackingPlayer; // which player scores into this goal
    [SerializeField]
    GameManagerScript gameMan; // this will hold a reference to the game manager script

    // Use this for initialization
    void Start () {
        playerOneScore = 0;
        playerTwoScore = 0;

        
    }
  
    // Update is called once per frame
    void Update () {
		
	}
  
    }

