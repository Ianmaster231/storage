﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ball : MonoBehaviour {
    [SerializeField]
    float forceValue = 4.5f;

    Rigidbody2D myBody;
    // Use this for initialization
    void Start()
    {
        myBody = GetComponent<Rigidbody2D>();
        myBody.AddForce(new Vector2(forceValue * 500, 500));
    }

    // Update is called once per frame
    void Update()
    {

    }
    public void Reset()
    {
        // reset the ball position and restart the ball movement
        myBody.velocity = Vector2.zero;
        transform.position = new Vector2(0, 0);
        Start(); // restart the ball 
    }
}