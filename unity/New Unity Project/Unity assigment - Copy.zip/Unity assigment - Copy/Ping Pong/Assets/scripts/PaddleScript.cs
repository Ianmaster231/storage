﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PaddleScript : MonoBehaviour
{

    public GameObject player1;
    public GameObject player2;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        player1.GetComponent<Rigidbody2D>().velocity = new Vector3(0f, 0f, 0f);

        //if player is pressing W
        if (Input.GetKey(KeyCode.W))
        {
            player1.GetComponent<Rigidbody2D>().velocity = new Vector3(0f, 20f, 0f);
        }
        // if player pressing s 
        if (Input.GetKey(KeyCode.S))
        {
            player1.GetComponent<Rigidbody2D>().velocity = new Vector3(0f, -20f, 0f);
        }

        player2.GetComponent<Rigidbody2D>().velocity = new Vector3(0f, 0f, 0f);

        //if player is pressing W
        if (Input.GetKey(KeyCode.UpArrow))
        {
            player2.GetComponent<Rigidbody2D>().velocity = new Vector3(0f, 20f, 0f);
        }
        // if player pressing s 
        if (Input.GetKey(KeyCode.DownArrow))
        {
            player2.GetComponent<Rigidbody2D>().velocity = new Vector3(0f, -20f, 0f);
        }
    }
}